package stratego;
public class TestMain {
    public static void main(String[] args) {
        Stratego stratego = new Stratego();
        stratego.playStratego();
    }
}